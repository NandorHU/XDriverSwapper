# XDriverSwapper 1.0.7 verification

- Policy tests: PASS, 2027 assertions and 100000 deterministic malformed inputs. They cover every combination of
  restart request, service, started state, problem code and pending restart for the restore decision.
- Executable built with Zig 0.13.0 (clang) for x86_64-windows-gnu. `libwdi.dll` is byte-identical to the 1.0.6 release.
- `--self-test` on Windows 11 x64 without administrator rights: PASS (policy + libwdi load).
- Main window started on Windows 11 x64 without administrator rights (no driver operation possible).
- Read-only Windows checks: present/absent detection (33 present USB nodes, 109 disconnected controller nodes),
  arrival time, INF users, INF hash and certificate subject matching: PASS.
- NOT tested: driver installation, restore, replug verification, package removal, certificate removal and Repair with
  administrator rights and a real controller. Treat 1.0.7 as a test release until this is done.
- Firmware is never modified.
