from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parent
with ZipFile(root/'payload/XDriverSwapper-Source.zip','w',ZIP_DEFLATED) as z:
 for name in ('src','vendor','tests','README.md','BUILD.sh','BUILD-WINDOWS.cmd','pack_source.py','pack_portable.py','installer.nsi','payload/OLVASS-EL.txt','payload/licenses'):
  p=root/name
  paths=p.rglob('*') if p.is_dir() else [p]
  for f in paths:
   if not f.is_file():continue
   rel=f.relative_to(root)
   if any(part in ('.git','.libs') for part in rel.parts):continue
   if f.suffix.lower() in ('.exe','.dll','.o','.res','.a','.la') or f.name in ('embedder','embedded.h'):continue
   z.write(f,'XDriverSwapper-Source/'+str(rel))
