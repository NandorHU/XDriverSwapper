from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parent
out=root/'dist/XDriverSwapper-Portable-v1.0.4.zip'
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((root/'payload').rglob('*')):
  if p.is_file():z.write(p,'XDriverSwapper/'+str(p.relative_to(root/'payload')))
print(out)
