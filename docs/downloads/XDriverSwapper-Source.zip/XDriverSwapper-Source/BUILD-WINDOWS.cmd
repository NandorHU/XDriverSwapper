@echo off
setlocal
cd /d "%~dp0"
where bash >nul 2>&1
if errorlevel 1 (
 echo MSYS2 MinGW64 shell szukseges a forditashoz.
 echo A kesz Setup EXE telepitesehez viszont semmilyen build-eszkoz nem kell.
 exit /b 1
)
bash BUILD.sh
exit /b %errorlevel%
