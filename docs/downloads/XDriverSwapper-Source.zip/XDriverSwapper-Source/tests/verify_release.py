from pathlib import Path
import pefile, hashlib, json, zipfile, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def check(ok,msg):
 if not ok:raise AssertionError(msg)
 checks.append(msg)
system={'advapi32.dll','bcrypt.dll','gdi32.dll','kernel32.dll','msvcrt.dll','ole32.dll','setupapi.dll','shell32.dll','user32.dll','ntdll.dll'}
for name in ('XDriverSwapper.exe','libwdi.dll'):
 p=root/'payload'/name;pe=pefile.PE(str(p));check(pe.FILE_HEADER.Machine==0x8664,name+' AMD64');check(pe.OPTIONAL_HEADER.Magic==0x20b,name+' PE32+')
 imports={x.dll.decode().lower() for x in pe.DIRECTORY_ENTRY_IMPORT};check(imports<=system,name+' only Windows system DLL imports')
 if name.endswith('.exe'):
  check(pe.OPTIONAL_HEADER.Subsystem==2,'native GUI subsystem')
  manifests=[]
  for t in pe.DIRECTORY_ENTRY_RESOURCE.entries:
   if t.id==24:
    for n in t.directory.entries:
     for l in n.directory.entries:
      d=l.data.struct;manifests.append(pe.get_data(d.OffsetToData,d.Size).decode())
  check(len(manifests)==1,'one embedded application manifest');check('requireAdministrator' in manifests[0],'administrator manifest');check('Microsoft.Windows.Common-Controls' in manifests[0],'native controls manifest')
 else:
  exports={x.name.decode() for x in pe.DIRECTORY_ENTRY_EXPORT.symbols if x.name}
  check({'wdi_create_list','wdi_destroy_list','wdi_prepare_driver','wdi_install_driver','wdi_strerror','wdi_is_driver_supported'}<=exports,'complete required libwdi exports')
inf=(root/'vendor/libwdi/libwdi/winusb.inf.in').read_text();check('Include = winusb.inf' in inf,'inbox WinUSB INF include');check('CoInstallers' not in inf,'no coinstaller requirements');check('WinUSB.sys' in inf,'inbox WinUSB.sys service');check('[libusbDevice_WinUSB.NTamd64]' in inf,'AMD64 INF model section')
embedded=(root/'vendor/libwdi/libwdi/embedded.h').read_text();check('WdfCoInstaller' not in embedded,'no WDK redistributable resource names');check('winusbcoinstaller2.dll' not in embedded,'no WinUSB coinstaller resource name')
source=(root/'src/main.cpp').read_text();check('UpdateDriverForPlugAndPlayDevices' not in source,'no model-wide direct driver switch');check('w.install(' not in source,'libwdi bulk install API not invoked');check('SetupUninstallOEMInfW(priorInf.c_str(),0,nullptr)' in source,'OEM uninstall never forced');check('DIGCF_ALLCLASSES' in source and 'DIGCF_PRESENT|DIGCF_ALLCLASSES' in source,'discovery present / cleanup all devices');check('made by NandorFIX' in source,'requested footer');check('findFactoryOrBackup(s,dev)' in source,'signed backup recovery available')
with zipfile.ZipFile(root/'payload/XDriverSwapper-Source.zip') as z:
 check(z.testzip() is None,'source ZIP CRC validation')
 for rel in ('src/main.cpp','src/policy.h','src/language.h','src/app.manifest','src/assets/app.ico','src/assets/logo.png','BUILD.sh','installer.nsi','vendor/libwdi/config.h','vendor/libwdi/libwdi/libwdi.c','vendor/libwdi/libwdi/winusb.inf.in'):
  check(z.read('XDriverSwapper-Source/'+rel)==(root/rel).read_bytes(),'bundled source matches '+rel)
 check(not any(x.endswith(('.exe','.dll')) for x in z.namelist()),'source archive has no Microsoft/driver binaries')
if len(sys.argv)>1:
 extracted=Path(sys.argv[1])
 for p in (root/'payload').rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(root/'payload');candidate=extracted/rel
  check(candidate.is_file(),'portable archive contains '+str(rel));check(hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(candidate.read_bytes()).digest(),'extracted byte equality '+str(rel))
result={'status':'PASS','checks':checks,'count':len(checks),'hardware_tested':False,'windows_execution_tested':False}
(root/'tests/verification-result.json').write_text(json.dumps(result,indent=2))
print('PASS:',len(checks),'PE, manifest, dependency, source, INF, and payload checks')
