# XDriverSwapper 1.0.5 verification

- Native policy tests: PASS, 1834 assertions and 100000 deterministic malformed inputs.
- Series PID 0B12 accepted; MI_00 accepted; other interfaces, Bluetooth, foreign vendors and malformed IDs rejected.
- Cross-build: PASS, Windows x64 EXE and libwdi DLL.
- PE/dependencies/manifest/INF/source checks: PASS (36 checks).
- Portable ZIP CRC: PASS.
- No Windows USB hardware execution was available. Driver installation and restoration for Series devices still require hardware validation.
- Firmware is never modified.
