# 1.0.4 Portable tesztjegyzőkönyv — 2026-10-13

Változások: Magyar/English nyelvválasztó, megjegyzett választás, azonnali UI-frissítés.
A napló új üzenetei és a megerősítő ablakok is a választott nyelvűek.
Az aktiválási kérés kábelkihúzást és visszadugást javasol.
A Windows-visszajelzés belső kezelése és a biztonságos driverellenőrzés megmaradt.

Natív Windows AMD64 keresztfordítás GCC 13.2.0-val, alkalmazás: -Wall -Wextra -Werror
(ismert Win32-struktúra és API-pointer figyelmeztetések kivételével).
Portable ZIP CRC-teszt; kicsomagolt fájlok bájtegyezése; PE-architektúra,
manifest, rendszer-DLL-függőségek, libwdi-exportok és pontos forrásazonosság.
1577 biztonsági döntési ellenőrzés és 100 000 hibás bemenet ASan/UBSan alatt.
A két nyelv megléte, azonnali frissítés/mentés bekötése és a kábeles
üzenetek forrásszinten ellenőrizve. A natív GUI futtatása nem állt rendelkezésre.

Windows 10/11 folyamatfuttatás és USB-hardveres teszt nem történt nálunk.
A felhasználó képe szerint az 1.0.1 az ő gépén WinUSB-t aktivált.
A 1.0.4 nyelvválasztó tényleges Windowsos megjelenése és működése még nem validált.
A korábbi Wine-próbát sockettiltás blokkolta.

Új ellenőrzések: beágyazott ICO és hét ikonméret; forrás-PNG bájtegyezése
a feltöltött logóval; XDriverSwapper EXE/product metadata; logó betöltése
a fejlécbe; gyári szolgáltatásellenőrzés előtt nincs sikerjelzés.
A készítői jelzés a jobb alsó sarokban marad.
A megjelenítés és a sikerjelző párbeszéd Windowsos futtatással nem validált.
