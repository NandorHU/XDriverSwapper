#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CC=${CC:-x86_64-w64-mingw32-gcc}
CXX=${CXX:-x86_64-w64-mingw32-g++}
WINDRES=${WINDRES:-x86_64-w64-mingw32-windres}
mkdir -p payload dist
(
 cd vendor/libwdi/libwdi
 "$CC" -O2 -static -I.. installer.c -o installer_x64.exe -lsetupapi -lnewdev -lole32
 cc -I.. embedder.c -o embedder
 ./embedder embedded.h
 "$WINDRES" -O coff libwdi.rc -o libwdi-res.o
 "$CC" -O2 -static-libgcc -shared -I.. logging.c tokenizer.c vid_data.c pki.c libwdi_dlg.c libwdi.c libwdi-res.o -o ../../../payload/libwdi.dll -lsetupapi -lole32 -lntdll
)
(cd src && "$WINDRES" -O coff app.rc -o app-res.o)
"$CXX" -std=c++17 -O2 -Wall -Wextra -Werror -Wno-missing-field-initializers -Wno-cast-function-type -static -municode -mwindows -Ivendor/libwdi/libwdi src/main.cpp src/app-res.o -o payload/XDriverSwapper.exe -lsetupapi -lcfgmgr32 -lshell32 -ladvapi32 -lole32 -lbcrypt -lcomctl32 -lgdi32 -luuid
# Package the directly runnable app, DLL and full corresponding source.
python3 pack_source.py
python3 pack_portable.py
