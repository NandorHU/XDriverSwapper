#pragma once
#include <string>
#include <algorithm>
#include <cwctype>
inline std::wstring lower(std::wstring x){std::transform(x.begin(),x.end(),x.begin(),towlower);return x;}
struct UsbTarget { bool accepted=false; unsigned short pid=0; int mi=-1; };
inline UsbTarget classify(std::wstring id){
 id=lower(id); UsbTarget t;
 if(id.rfind(L"usb\\vid_045e&pid_",0)!=0 || id.size()<21)return t;
 auto hex=[](wchar_t c){return (c>=L'0'&&c<=L'9')||(c>=L'a'&&c<=L'f');};
 const size_t p=17;
 for(size_t k=p;k<p+4;k++)if(!hex(id[k]))return t;
 t.pid=static_cast<unsigned short>(std::stoul(id.substr(p,4),nullptr,16));
 if(id.size()>21 && id[21]!=L'&'&&id[21]!=L'\\')return t;
 if(t.pid!=0x02d1 && t.pid!=0x02dd && t.pid!=0x02e3 && t.pid!=0x02ea && t.pid!=0x0b00 && t.pid!=0x0b05 && t.pid!=0x0b12)return t;
 auto m=id.find(L"&mi_"); if(m!=std::wstring::npos){if(m+6>id.size()||!hex(id[m+4])||!hex(id[m+5]))return t;if(id.size()>m+6 && id[m+6]!=L'\\')return t;t.mi=std::stoi(id.substr(m+4,2),nullptr,16);if(t.mi!=0)return t;}
 t.accepted=true; return t;
}
inline bool factoryService(std::wstring s){s=lower(s);return s==L"xboxgip"||s==L"xinputhid"||s==L"dc1-controller";}
inline bool oemInf(std::wstring x){x=lower(x); if(x.size()<8||x.rfind(L"oem",0)!=0||x.substr(x.size()-4)!=L".inf")return false;for(size_t i=3;i<x.size()-4;i++)if(x[i]<L'0'||x[i]>L'9')return false;return true;}
