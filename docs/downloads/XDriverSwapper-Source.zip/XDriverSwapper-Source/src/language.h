#pragma once
#include <atomic>
#include <string>
inline std::atomic<bool> english{false};
inline std::wstring tr(const wchar_t*hu,const wchar_t*en){return english.load()?en:hu;}
inline std::string trA(const char*hu,const char*en){return english.load()?en:hu;}
