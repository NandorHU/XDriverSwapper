#include "policy.h"
#include <iostream>
#include <random>
#include <cassert>
int main(){
 int checks=0;auto check=[&](bool v){++checks;if(!v){std::cerr<<"FAIL at "<<checks<<"\n";exit(1);}};
 for(auto pid:{L"02D1",L"02DD",L"02E3",L"02EA",L"0B00",L"0B05",L"0B12"}){
  auto root=std::wstring(L"USB\\VID_045E&PID_")+pid;
  check(classify(root+L"\\123456").accepted);check(classify(root+L"&MI_00\\123456").accepted);
  for(int i=1;i<256;i++){wchar_t mi[3];swprintf(mi,3,L"%02X",i);check(!classify(root+L"&MI_"+mi+L"\\123456").accepted);}
  check(!classify(root+L"&MI_000\\123456").accepted);
 }
 for(auto id:{L"USB\\VID_045E&PID_028E\\1",L"USB\\VID_045E&PID_0719\\1",L"USB\\VID_045E&PID_02E6\\1",L"USB\\VID_045E&PID_02EAX\\1",L"HID\\VID_045E&PID_02EA\\1",L"BTHENUM\\VID_045E&PID_02EA\\1",L"USB\\VID_1234&PID_02EA\\1",L"USB\\VID_045E&PID_XXXX\\1",L"USB\\VID_045E&PID_02EA&MI_XX\\1"})check(!classify(id).accepted);
 check(factoryService(L"XboxGip"));check(factoryService(L"xinputhid"));check(factoryService(L"dc1-controller"));check(factoryService(L"DC1-Controller"));check(!factoryService(L"dc1-controller-malicious"));check(!factoryService(L"dc1_controller"));for(auto s:{L"winusb",L"USBCCGP",L"HidUsb",L"xboxgip2",L""})check(!factoryService(s));
 for(auto s:{L"oem0.inf",L"oem123.inf",L"OEM42.INF"})check(oemInf(s));
 for(auto s:{L"oem.inf",L"xinputhid.inf",L"oem1.inf /force",L"..\\oem1.inf",L"oemA.inf"})check(!oemInf(s));
 std::mt19937 rng(123456);for(int i=0;i<100000;i++){std::wstring s;for(int j=0,n=rng()%80;j<n;j++)s+=static_cast<wchar_t>(32+rng()%95);auto t=classify(s);if(t.accepted)check(t.pid==0x02d1||t.pid==0x02dd||t.pid==0x02e3||t.pid==0x02ea||t.pid==0x0b00||t.pid==0x0b05||t.pid==0x0b12);}
 std::cout<<"PASS: "<<checks<<" assertions plus 100000 deterministic malformed-input cases\n";
}
