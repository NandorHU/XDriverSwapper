Portable usage: extract the whole ZIP and run XDriverSwapper.exe.
Keep libwdi.dll beside the EXE. Administrator approval is required for system driver operations.
Version 1.0.4 adds dc1-controller factory-service support and rejection diagnostics.

# XDriverSwapper 1.0.4 Portable

Native Win32 C++17 application targeting Windows 10/11 AMD64. No .NET, WMI,
PowerShell, manual driver-component download, or third-party runtime is required.
The portable ZIP contains the application, dynamically linked libwdi, licensing,
Hungarian instructions, and the exact source bundle.

This is a compiled release candidate, not hardware-validated production software.
See `tests/TEST-REPORT.md` for what was actually checked.

## Behavior

- SetupAPI enumeration of present USB devices, polling and device-change refresh.
- Hardware allowlist: Microsoft VID 045E, Xbox One/Elite PID 02D1/02DD/02E3/02EA/0B00/0B05.
- Composite interface MI_00 only; USBCCGP parents, adapters, audio interfaces,
  Xbox 360, Series, Bluetooth and other vendors are excluded.
- Discovery survives device-name changes after switching to WinUSB.
- Microsoft-provider, Microsoft-signed compatible factory INF with associated
  XboxGip, xinputhid or dc1-controller service must exist before the first switch.
- Before replacement, saves device/INF/service identity and copies the factory
  Driver Store package. Admin/SYSTEM-owned state and protected ACL.
- Modified libwdi prepares an INF and locally signed CAT that references Windows'
  inbox WinUSB.sys. No Microsoft driver binary is redistributed.
- SetupCopyOEMInf stages the package; DiInstallDevice installs to the exact
  selected instance. Does not call libwdi's model-wide driver-install function.
- Restore chooses a verified compatible factory driver and installs it to the
  selected instance. If needed, restages a Microsoft-signed matching saved package.
- Active service is checked; pending activation prompts USB cable reconnection.
- Unused owned OEM packages are identified by saved SHA-256 and removed only
  without force, after checking all present and non-present devices. Other
  packages and system INFs are never deleted.
- Installer/uninstaller do not change drivers. Backups survive uninstall.
- Only one app instance; mutations run off the UI thread; close is blocked while busy.
- White background, black text; `made by NandorFIX` at bottom right.

## Known limits

No actual Windows process execution or USB driver mutation was available here.
The environment blocks Wine server sockets. Windows security policies may block
locally signed catalogs; the tool must report failure without changing security
policy. SmartScreen may warn because the release executables are not Authenticode-signed.

A hardware-ID INF is model-specific, even though DiInstallDevice targets a single
instance. On a different port or another identical controller Windows may select
that package. Restore there as needed. A package still used by another present or
phantom device is retained and logged. No universal offline Xbox driver is bundled.
Factory drivers must come from Windows/Windows Update, or the local saved package.

libwdi locally creates a unique NandorFIX certificate and adds it to Root and
TrustedPublisher. Certificates are retained; there is no automatic certificate
cleanup that could affect installed driver packages. No test-signing, Secure Boot,
or Memory Integrity setting is modified.

The factory backup is local recovery data, not an externally distributable artifact.
Its bytes are never included in the setup/source archive.

## Build

Linux: MinGW-w64 x86_64 GCC/G++, binutils (windres), native GCC, Python 3, NSIS.
Windows: run in MSYS2 MinGW64 with equivalent packages, native GCC for the embedder,
Python 3 and NSIS available on PATH. `bash BUILD.sh` fails immediately on errors.

`BUILD.sh` compiles the helper and DLL, generates the application manifest/version
resources, links the application statically to its compiler runtime, packs exact
source, and creates the portable ZIP without NSIS or an installer. No WDK or .NET is required.

`g++ -std=c++17 -O1 -g -fsanitize=address,undefined src/policy_tests.cpp -o policy-tests`
then `ASAN_OPTIONS=detect_leaks=0 ./policy-tests` runs pure decision tests.
LeakSanitizer was disabled because this environment cannot inspect process tasks;
AddressSanitizer and UndefinedBehaviorSanitizer remained enabled.

On an actual Windows test machine, `XDriverSwapper.exe --self-test` checks
policy predicates and DLL load/API support, writing `self-test.txt` beside the EXE.
This command performs no driver change. It has NOT been run here. Use a writable
copy of the installed program folder if required for the report file.

## libwdi provenance and modifications

Upstream: https://github.com/pbatard/libwdi
Commit: 30df0c0e051b0132c4b9ebed8c054bc8eb3aaaec
Upstream LGPLv3-or-later license and notices remain in the bundled source.

NandorFIX modifications dated 2026-10-13:
- `config.h`: manual MinGW build config, AMD64 only, NANDORFIX_INBOX_WINUSB.
- `libwdi/embedder.h`: permits an inbox-only WinUSB build without WDK files.
- `libwdi/libwdi.c`: advertises the inbox variant and uses version 10.0.0.0,
  date 2024-01-01 for the generated device INF without extracting a WDK DLL.
- `libwdi/winusb.inf.in`: removes coinstaller/WDF redistribution sections.
- `libwdi/winusb.cat.in`: INF-only catalog file list; no driver binary payload.

The libwdi DLL stays dynamically replaceable. Its complete corresponding source,
including local config and build instructions, is shipped in the same installer.
Application source is MIT-licensed; the DLL remains LGPL. Users may replace/rebuild
libwdi and reverse-engineer the application for debugging library modifications.

## 1.0.4 changes

Magyar / English selector updates the interface and future log messages immediately.
The choice is saved in language.ini beside the portable EXE. If the folder is
read-only, language switching still works for the current session. Native Windows
error descriptions retain their Windows language; device names and paths are not translated.
During a driver operation language switching is disabled for consistent messages.
Pending activation messages now ask to unplug and reconnect the USB cable.
Driver verification and conservative cleanup guards are unchanged.

## 1.0.4 branding and restoration result

Executable and product: XDriverSwapper. Original provided PNG is retained in
source assets; alpha-bounded margin normalization and proportional ICO conversion
add seven Windows icon sizes. The same ICO is embedded in the EXE and shown
in the header. Product title and dialog captions use XDriverSwapper; maker
credit remains only at bottom right. Legacy state paths/mutex are retained
to reuse original backups and prevent simultaneous old/new driver operations.

Restoration completion is announced in the log, a persistent status label,
and an information dialog only after the factory service is verified.
If activation is pending, automatic detection waits for the same instance
to return with a recognized factory service before announcing completion.
Optional package-cleanup failure is reported separately from verified restoration.
All new user-visible messages support Hungarian and English.

1.0.4 adds an underlined clickable website directly below the bottom-right
maker credit. ShellExecute opens https://www.konzol-szerviz.hu/ in the default
browser only when clicked. Footer space was increased to prevent clipping.
