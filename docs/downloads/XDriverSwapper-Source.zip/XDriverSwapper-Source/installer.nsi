Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "WinVer.nsh"
Name "NandorFIX Xbox Driver Manager"
OutFile "dist/NandorFIX-Xbox-Driver-Manager-Setup.exe"
InstallDir "$PROGRAMFILES64\NandorFIX Xbox Driver Manager"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
SetCompressorDictSize 32
VIProductVersion "1.0.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "NandorFIX Xbox Driver Manager"
VIAddVersionKey /LANG=1033 "FileVersion" "1.0.0"
VIAddVersionKey /LANG=1033 "FileDescription" "NandorFIX Driver Manager Setup"
VIAddVersionKey /LANG=1033 "LegalCopyright" "Copyright (c) 2026 NandorFIX"
!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_LICENSE "payload/licenses/NOTICE.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Hungarian"
!insertmacro MUI_LANGUAGE "English"
Function .onInit
 ${IfNot} ${IsNativeAMD64}
  MessageBox MB_ICONSTOP "Windows 10/11 x64 (AMD64) szükséges."
  Abort
 ${EndIf}
 ${IfNot} ${AtLeastWin10}
  MessageBox MB_ICONSTOP "Windows 10 vagy Windows 11 szükséges."
  Abort
 ${EndIf}
 SetRegView 64
FunctionEnd
Section "NandorFIX Driver Manager" SecMain
 SetShellVarContext all
 SetOutPath "$INSTDIR"
 File "payload/NandorFIX.DriverManager.exe"
 File "payload/libwdi.dll"
 File "payload/OLVASS-EL.txt"
 File "payload/NandorFIX-Source.zip"
 SetOutPath "$INSTDIR\licenses"
 File /r "payload/licenses/*"
 WriteUninstaller "$INSTDIR\Uninstall.exe"
 CreateDirectory "$SMPROGRAMS\NandorFIX"
 CreateShortCut "$SMPROGRAMS\NandorFIX\Xbox Driver Manager.lnk" "$INSTDIR\NandorFIX.DriverManager.exe"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "DisplayName" "NandorFIX Xbox Driver Manager"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "DisplayVersion" "1.0.0"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "Publisher" "NandorFIX"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "UninstallString" '"$INSTDIR\Uninstall.exe"'
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "DisplayIcon" "$INSTDIR\NandorFIX.DriverManager.exe"
 WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "NoModify" 1
 WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager" "NoRepair" 1
SectionEnd
Section "Uninstall"
 SetRegView 64
 SetShellVarContext all
 MessageBox MB_OK "Az eltávolítás nem módosít USB-drivereket. Ha WinUSB-t használsz, előbb állítsd vissza a gyári Xbox-drivert az alkalmazásban. A mentések megmaradnak."
 Delete "$INSTDIR\NandorFIX.DriverManager.exe"
 Delete "$INSTDIR\libwdi.dll"
 Delete "$INSTDIR\OLVASS-EL.txt"
 Delete "$INSTDIR\NandorFIX-Source.zip"
 Delete "$INSTDIR\licenses\NOTICE.txt"
 Delete "$INSTDIR\licenses\COPYING-LGPL"
 Delete "$INSTDIR\licenses\COPYING-GPL"
 Delete "$INSTDIR\licenses\LICENSE-NandorFIX.txt"
 RMDir "$INSTDIR\licenses"
 Delete "$INSTDIR\Uninstall.exe"
 RMDir "$INSTDIR"
 Delete "$SMPROGRAMS\NandorFIX\Xbox Driver Manager.lnk"
 RMDir "$SMPROGRAMS\NandorFIX"
 DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\NandorFIX.DriverManager"
SectionEnd
